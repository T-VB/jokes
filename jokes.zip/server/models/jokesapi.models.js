const mongoose = require("mongoose");

//define schema (attributes/properties listed out)
const JokesApiSchema = new mongoose.Schema(
  {
    setup: String,
    punchline: String,
  },
  { timestamps: true }
);

//define model as 'Joke' and list the the name 1st param and the schema name as the 2nd parameter
const Joke = mongoose.model("Joke", JokesApiSchema);

module.exports = Joke;
